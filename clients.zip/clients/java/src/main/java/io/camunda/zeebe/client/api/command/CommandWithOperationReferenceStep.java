/*
 * Copyright © 2017 camunda services GmbH (info@camunda.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.camunda.zeebe.client.api.command;

public interface CommandWithOperationReferenceStep<T> {

  /**
   * Set the Operation Reference.
   *
   * <p>This is a key chosen by the user and will be part of all records resulted from this
   * operation
   *
   * @param operationReference a reference key chosen by the user and will be part of all records
   *     resulted from this operation
   * @return the builder for this command with the operation reference specified
   * @since 8.6
   */
  T operationReference(long operationReference);
}
